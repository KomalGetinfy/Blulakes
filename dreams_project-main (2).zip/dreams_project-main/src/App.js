import './App.css';
import Classindex from './Components/classindex';

function App() {
  return (
    <div className="App">
       <Classindex/>
    </div>
  );
}

export default App;
